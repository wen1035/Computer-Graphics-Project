This model is licensed under the Creative Commons CC-BY-SA 3.0 license

http://creativecommons.org/licenses/by-sa/3.0/

It can be used as long as attribution is given and any modifications
are under the same license

It was created by [ahedov](https://www.blendswap.com/user/ahedov)

https://www.blendswap.com/blends/view/69174
